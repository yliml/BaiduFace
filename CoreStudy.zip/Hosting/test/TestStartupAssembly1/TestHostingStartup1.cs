﻿// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System;
using System.Threading.Tasks;

[assembly: HostingStartup(typeof(TestStartupAssembly1.TestHostingStartup1))]

namespace TestStartupAssembly1
{
    public class TestHostingStartup1 : IHostingStartup
    {
        public void Configure(IWebHostBuilder builder)
        {
            builder.UseSetting("testhostingstartup1", "1");
            builder.UseSetting("testhostingstartup_chain", builder.GetSetting("testhostingstartup_chain") + "1");
            builder.ConfigureServices(service=> {
                service.Add(new Microsoft.Extensions.DependencyInjection.ServiceDescriptor(typeof(IPeople),new People("testhostingstartup1")));
            });

            builder.Configure(app =>
            {
                app.Run(context =>
                {
                    Console.WriteLine("其他库配置Middleware");
                    context.Response.WriteAsync("111");
                    return Task.CompletedTask;
                });
            });
        }
    }


    public class People : IPeople
    {
        public People(string word)
        {
            _word = word;
        }

        private string _word;
        public void SayHello()
        {
            Console.WriteLine($"Hello World{_word}");
        }
    }

    public interface IPeople
    {
        void SayHello();
    }
}
