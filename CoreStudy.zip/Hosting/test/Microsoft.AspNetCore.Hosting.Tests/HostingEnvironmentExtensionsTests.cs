// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.

using System.IO;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.Extensions.FileProviders;
using Xunit;

namespace Microsoft.AspNetCore.Hosting.Tests
{
    public class HostingEnvironmentExtensionsTests
    {
        [Fact]
        public void SetsFullPathToWwwroot()
        {
            var env = new HostingEnvironment();

            env.Initialize("DummyApplication", Path.GetFullPath("."), new WebHostOptions(){ WebRoot = "testroot" });

            Assert.Equal(Path.GetFullPath("."), env.ContentRootPath);
            Assert.Equal(Path.GetFullPath("testroot"), env.WebRootPath);
            Assert.IsAssignableFrom<PhysicalFileProvider>(env.ContentRootFileProvider);
            Assert.IsAssignableFrom<PhysicalFileProvider>(env.WebRootFileProvider);
        }

        [Fact(Skip = "Missing content publish property")]
        public void DefaultsToWwwrootSubdir()
        {
            var env = new HostingEnvironment();

            env.Initialize("DummyApplication", Path.GetFullPath("testroot"), new WebHostOptions());

            Assert.Equal(Path.GetFullPath("testroot"), env.ContentRootPath);
            Assert.Equal(Path.GetFullPath(Path.Combine("testroot", "wwwroot")), env.WebRootPath);
            Assert.IsAssignableFrom<PhysicalFileProvider>(env.ContentRootFileProvider);
            Assert.IsAssignableFrom<PhysicalFileProvider>(env.WebRootFileProvider);
        }

        [Fact]
        public void DefaultsToNullFileProvider()
        {
            var env = new HostingEnvironment();

            env.Initialize("DummyApplication", Path.GetFullPath(Path.Combine("testroot", "wwwroot")), new WebHostOptions());

            Assert.Equal(Path.GetFullPath(Path.Combine("testroot", "wwwroot")), env.ContentRootPath);
            Assert.Null(env.WebRootPath);
            Assert.IsAssignableFrom<PhysicalFileProvider>(env.ContentRootFileProvider);
            Assert.IsAssignableFrom<NullFileProvider>(env.WebRootFileProvider);
        }

        [Fact]
        public void OverridesEnvironmentFromConfig()
        {
            var env = new HostingEnvironment();
            env.EnvironmentName = "SomeName";

            env.Initialize("DummyApplication", Path.GetFullPath("."), new WebHostOptions(){ Environment = "NewName" });

            Assert.Equal("NewName", env.EnvironmentName);
        }
    }
}
